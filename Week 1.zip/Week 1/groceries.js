/*
Instructions
Create a file called grocery.ts. It should have a definition of a class with the obvious name Grocery.
The class should have some basic attributes such as name, quantity, etc. Feel free to add any other
attributes you think will be necessary.
Add few grocery items to an array of groceries, such as milk, bread, and eggs, along with some
quantities (i.e. 3, 6, 11).  Display these grocery items as HTML output.
The output of this assignment will be grocery.ts and groceries.html displaying the output.
*/
var Grocery = /** @class */ (function () {
    function Grocery(name, quantity, price, description) {
        this.name = name;
        this.quantity = quantity;
        this.price = price;
        this.description = description;
    }
    return Grocery;
}());
var apple = new Grocery("Apple", 8, 3.99, "Bag of 8 apples");
var peanutButter = new Grocery("Peanut Butter", 1, 2.51, "Jar of Peanut Butter");
var milk = new Grocery("Milk", 1, 3.75, "Gallon of milk");
var bread = new Grocery("Bread", 1, 1.99, "Loaf of bread");
var eggs = new Grocery("Eggs", 12, 2.89, "One dozen eggs");
var grocArray = [apple, peanutButter, milk, bread, eggs];
var html = "<table border='1|1'>";
for (var i = 0; i < grocArray.length; i++) {
    html += "<tr>";
    html += "<td>" + grocArray[i].name + "</td>";
    html += "<td>" + grocArray[i].quantity + "</td>";
    html += "<td>" + grocArray[i].price + "</td>";
    html += "<td>" + grocArray[i].description + "</td>";
    html += "</tr>";
}
html += "</table>";
document.body.innerHTML = html;
